﻿using System;
using System.Text;
using System.Net.Sockets;


namespace Client
{
    class Program
    {
        static void Main(string[] args)
        {
            TcpClient client = null;

            try
            {
                client = new TcpClient("localhost", 8000);
                NetworkStream stream = client.GetStream();

                while (true)
                {

                    byte[] data = new byte[1024];

                    string message = Console.ReadLine();

                    data = Encoding.Unicode.GetBytes(message);
                    stream.Write(data, 0, data.Length);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
              client.Close();
            }
        }
    }
}
