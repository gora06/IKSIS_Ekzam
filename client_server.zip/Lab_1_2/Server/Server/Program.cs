﻿using System;
using System.Text;
using System.Net.Sockets;
using System.Threading;
using System.Net;

namespace Server
{
    public class ClientObject
    {
        public TcpClient client;
        public ClientObject(TcpClient tcpClient)
        {
            client = tcpClient;
        }

        public void Process()
        {

        NetworkStream stream = null;
        
            try
            {
                stream = client.GetStream();

                byte[] data = new byte[1024];
                while (true)
                {
                    string builder;
                    int bytes = 0;
                    do
                    {
                        bytes = stream.Read(data, 0, data.Length);
                        builder = Encoding.Unicode.GetString(data, 0, bytes);

                        Console.WriteLine(builder);

                    }
                    while (stream.DataAvailable);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                if (stream != null)
                    stream.Close();
                if (client != null)
                    client.Close();
                
            }
                       
        }
    }

    class Program
    {
        static TcpListener listener;

        static void Main(string[] args)
        {
            try
            {
                listener = new TcpListener(Dns.GetHostEntry("localhost").AddressList[0], 8000);
                listener.Start();
                Console.WriteLine("Waiting for connection...");

                while (true)
                {
                    TcpClient client = listener.AcceptTcpClient();
                    Console.WriteLine("New connection enstabliched");
                    ClientObject clientObject = new ClientObject(client);

                    Thread clientThread = new Thread(new ThreadStart(clientObject.Process));
                    clientThread.Start();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                if (listener != null)
                    listener.Stop();
            }
        }
    }
}
